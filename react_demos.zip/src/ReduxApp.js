import React, { Component } from 'react';
import BankApp from './components/redux/BankApp';
import Demo from './components/redux/Demo';
import DemoThunk from './components/redux/DemoThunk';
import ReduxDemo from './components/redux/ReduxDemo';


class ReduxApp extends Component {
    constructor(props) {
        super(props);
        this.state = {  };
    }
    render() {
        return (
           <>
           {/* <ReduxDemo/> */}
           {/* <Demo/> */}
           {/* <BankApp/> */}
           <DemoThunk/>
           </> 
        );
    }
}

export default ReduxApp;