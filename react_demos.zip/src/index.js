import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { Employee } from './components/Employee';
import 'bootstrap/dist/css/bootstrap.css';
import Book from './components/Book';
import functionClick from './components/FunctionClick';
import FunctionClick from './components/FunctionClick';
import ListDemo from './components/ListDemo';
import 'bootstrap/dist/css/bootstrap.min.css'


import Booklist from './components/crud/Booklist';
import Cinput from './components/ref/Cinput';
import Cform from './components/ref/Cform';
import PureCompDemo from './components/pureComp/PureCompDemo';
import Lifecycledemo from './components/lifecycle/Lifecycledemo';
import RouteApp from './components/RouteDemo/RouteApp';
import RestBooklist from './components/restapi/RestBooklist';
import ReduxDemo from './components/redux/ReduxDemo';
import { Provider } from 'react-redux';
import { createStore,applyMiddleware } from 'redux';
import reducer from './components/redux/reducer';
import bankreducer from './components/redux/BankReducer';
import ReduxApp from './ReduxApp';
import thunk from "redux-thunk"
import reducerthunk from './components/redux/reducerthunk';

//const store=createStore(reducer);
//const store=createStore(bankreducer);
const store=createStore(reducerthunk,applyMiddleware(thunk));


ReactDOM.render(
  <React.StrictMode>
   
     {/* <Cinput/>  */}
     {/* <Cform/> */}
     {/* <PureCompDemo/> */}
     {/* <Booklist/>  */}
    {/* <Lifecycledemo/> */}
  {/* <RouteApp/> */}
  {/* <RestBooklist/> */}
  <Provider store={store}>
<ReduxApp/>
</Provider>


  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
