import React, { Component, PureComponent } from 'react';   
class PureCompDemo extends PureComponent{
    constructor(props) {
        super(props);
        this.state = { val:1  };
    }

componentDidMount()
{
    setInterval(() => {
        this.setState({val:Math.random()})
    }, 2000);
}

componentWillUnmount()
{
    clearInterval();
}


// shouldComponentUpdate(nextProps,nextState)
// {
//     console.log("value:"+nextState.val)
//     return(this.state.val===nextState.val? false : true);
// }

    render() {
        console.log("render method")
        return (
            <>
            <p>{this.state.val}</p>
            </>

            
        );
    }
}

export default PureCompDemo;