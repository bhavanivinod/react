
import React, { Component } from 'react';

class RestBookForm extends Component {
    constructor(props) {
        super(props);
        
        this.state = {

            "id": 0,
            "title": "",
            "author": "",
            "description": " ",
            "published": 0

           
        };
        
    }



componentWillReceiveProps(nextProps) {
   
    if(this.state.id!=nextProps.book.id)
    {
    this.setState({"id": nextProps.book.id,
    "title": nextProps.book.title,
    "description":nextProps.book.description,
    "author": nextProps.book.author,

    "published": nextProps.book.published});
    }
}
    
    

    
        handleOnchange(event) {

        console.log(event.target.name+":"+event.target.value)

        this.setState({ [event.target.name]: event.target.value })
        
    }

    handleOnsubmit(event) {
        event.preventDefault();
        this.props.handleAddBook(this.state);
        
    }

   
componentDidMount()
{
    console.log("component mounted")
}



    render() {
     
        return (
            <div>
                <form onSubmit={(e) => this.handleOnsubmit(e)}>
                    <div>
                        Id:
    <input type="text" name="id" value={this.state.id} onChange={(event) => this.handleOnchange(event)} />
                    </div>
                    <div>
                        Title:
    <input type="text" name="title" value={this.state.title} onChange={(event) => this.handleOnchange(event)} />
                    </div><div>
                    Description:
    <input type="text" name="description" value={this.state.description} onChange={(event) => this.handleOnchange(event)} />
                    </div><div>
                        Author:
    <input type="text" name="author" value={this.state.author} onChange={(event) => this.handleOnchange(event)} />
                    </div><div>
                    published:
    <input type="text" name="published" value={this.state.published} onChange={(event) => this.handleOnchange(event)} />
                    </div>
                    <input type="submit" value="save"/>
                    



                </form>


            </div>
        );
    }
}

export default RestBookForm;