import React, { Component } from 'react';
import RestBookForm from './RestBookForm'
import axios from 'axios'


class RestBooklist extends Component {
    constructor(props) {
        super(props);
        this.state = {
            books: [],
            message: "",
            book: {
                "id": 0,
                "title": "0",
                "author": "0",
                "description": " 0",
                "published": 0
            },
            updateFlag:false

        };
    }

    handleAddBook(book) {
if(this.state.updateFlag)
{
        axios.put('http://localhost:3456/api/books/' + book.id,book).then((res) => {
            console.log(res.status)
            res.status>=200&&res.status<300?this.setState({ message:'book data updtaed ',updateFlag:false },()=>{this.getData()}):this.setState({ message:'',updateFlag:false })

        }).catch((err) => {
            console.log(err)
        }) 
    }
    else{
        axios.post('http://localhost:3456/api/books/create',book).then((res) => {
            console.log(res.status)
            res.status>=200&&res.status<300?this.setState({ message:'book saved successfully '},()=>{this.getData()}):this.setState({ message:'' })

        }).catch((err) => {
            console.log(err)
        }) 

    }
    }

    handleRemove(id) {
        axios.delete('http://localhost:3456/api/books/' + id).then((res) => {
            this.setState({ message: res.data },()=>this.getData())

        }).catch((err) => {
            console.log(err)
        })
        

    }

    handleEditbook(id) {
        axios.get('http://localhost:3456/api/books/'+id).then((res) => {
            let book=res.data
            this.setState({book,updateFlag:true})
           
    })


        
    }

    getData()
    {
        axios.get('http://localhost:3456/api/books').then((res) => {
            console.log(res.data)
            let books = res.data
            this.setState({ books })
        }).catch((err) => {
            console.log(err)

        })
    }

    componentDidMount()
    {
               this.getData();
            }


    render() {

            console.log("render called");
            return(
                <div>
                    <h5 style={{color:'green'}}>{this.state.message}</h5>

                    <table className="table table-dark">
                        <thead>

                            <th>id</th>
                            <th>title</th>
                           
                            <th>author</th>
                            <th>description</th>
                            <th>published</th>
                            <th>actions</th>

                        </thead>
                        <tbody>
                            {this.state.books.map((book) => {


                                return (
                                    <tr  key={book.id}>
                                        <td>{book.id}</td>
                                        <td>{book.title}</td>
                                        <td>{book.author}</td>
                                        <td>{book.description}</td>
                                        
                                        <td>{book.published}</td>
                                        <button className="btn btn-primary" onClick={() => this.handleEditbook(book.id)} >edit</button>
                                        <button className="btn btn-danger" onClick={() => this.handleRemove(book.id)}>delete</button>
                                    </tr>


                                );

                            })}
                        </tbody>
                    </table>

                   {!this.state.updateFlag ?
                        <div>
                            <h3>Add New Books</h3>
                            <RestBookForm book={this.state.book}  handleAddBook={this.handleAddBook.bind(this)} />
                        </div> :
                        <div>
                            <h3>Update Book detail</h3>
                            <RestBookForm book={this.state.book} handleAddBook={this.handleAddBook.bind(this)} />
                        </div> 
    }

                       

                </div >
            );








    }
}

export default RestBooklist;