import React, { Component } from 'react';

class BookForm extends Component {
    constructor(props) {
        super(props);
        
        this.state = {

            "isbn": '',
            "title": '',
            "subtitle": '',
            "author": '',

            "pages": 0,

           
        };
        
    }



componentWillReceiveProps(nextProps) {
    console.log("component will receive"+nextProps.book.title)
    if(this.state.isbn!=nextProps.isbn)
    {
    this.setState({"isbn": nextProps.book.isbn,
    "title": nextProps.book.title,
    "subtitle":nextProps.book.subtitle,
    "author": nextProps.book.author,

    "pages": nextProps.book.pages});
    }
}
    
    

    
        handleOnchange(event) {

        console.log(event.target.name+":"+event.target.value)

        this.setState({ [event.target.name]: event.target.value })
        
    }

    handleOnsubmit(event) {
        event.preventDefault();
        this.props.handleAddBook(this.state);
        
    }

   
componentDidMount()
{
    console.log("component mounted")
}



    render() {
     
        return (
            <div>
                <form onSubmit={(e) => this.handleOnsubmit(e)}>
                    <div>
                        ISBN:
    <input type="text" name="isbn" value={this.state.isbn} onChange={(event) => this.handleOnchange(event)} />
                    </div>
                    <div>
                        Title:
    <input type="text" name="title" value={this.state.title} onChange={(event) => this.handleOnchange(event)} />
                    </div><div>
                        subtitle:
    <input type="text" name="subtitle" value={this.state.subtitle} onChange={(event) => this.handleOnchange(event)} />
                    </div><div>
                        Author:
    <input type="text" name="author" value={this.state.author} onChange={(event) => this.handleOnchange(event)} />
                    </div><div>
                        Pages:
    <input type="text" name="pages" value={this.state.pages} onChange={(event) => this.handleOnchange(event)} />
                    </div>
                    <input type="submit" value="save"/>
                    



                </form>


            </div>
        );
    }
}

export default BookForm;