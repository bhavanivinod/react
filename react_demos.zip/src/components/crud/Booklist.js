import React, { Component } from 'react';
import BookForm from './BookForm';
import './myStyles.css'


class Booklist extends Component {
    constructor(props) {
        super(props);
        this.state = {
            "books": [
                {
                    "isbn": "9781593275846",
                    "title": "Eloquent JavaScript, Second Edition",
                    "subtitle": "A Modern Introduction to Programming",
                    "author": "Marijn Haverbeke",

                    "pages": 472

                },
                {
                    "isbn": "9781449331818",
                    "title": "Learning JavaScript Design Patterns",
                    "subtitle": "A JavaScript and jQuery Developer's Guide",
                    "author": "Addy Osmani",

                    "pages": 254,

                },
                {
                    "isbn": "9781449365035",
                    "title": "Speaking JavaScript",
                    "subtitle": "An In-Depth Guide for Programmers",
                    "author": "Axel Rauschmayer",


                    "pages": 460

                },
                {
                    "isbn": "9781491950296",
                    "title": "Programming JavaScript Applications",
                    "subtitle": "Robust Web Architecture with Node, HTML5, and Modern JS Libraries",
                    "author": "Eric Elliott",

                    "pages": 254

                },
                {
                    "isbn": "9781593277574",
                    "title": "Understanding ECMAScript 6",
                    "subtitle": "The Definitive Guide for JavaScript Developers",
                    "author": "Nicholas C. Zakas",
                    "pages": 352

                },
                {
                    "isbn": "9781491904244",
                    "title": "You Don't Know JS",
                    "subtitle": "ES6 & Beyond",
                    "author": "Kyle Simpson",
                    "pages": 278

                }],

            book: {
                "isbn": '',
            "title": '',
            "subtitle": '',
            "author": '',

            "pages": 0,
            },
            updateFlag: false

        };
    }

    handleAddBook(book) {
        console.log("calling parent add");
        let newstate = [...this.state.books, book]

        this.setState({ books: newstate, updateFlag: false,book:{"isbn": '',
        "title": '',
        "subtitle": '',
        "author": '',

        "pages": 0,} })
    }

    handleRemove(ind) {
        const current = this.state;
        let newstate = current.books.filter((book, index) => {
            return index != ind
        });
        this.setState({ books: newstate })
    }

    handleEditbook(ind) {

        let b = this.state.books.slice(ind, ind + 1);
        let newBook = b[0];

        const current = this.state;
        let newstate = current.books.filter((book, index) => {
            return index != ind
        });

        this.setState({ book: newBook, books: newstate, updateFlag:true });


    }


    render() {
        let styletr=this.state.updateFlag ? 'colorbg':''
        console.log("render called");
            return (
                <div>

                    <table className="table table-dark">
                        <thead>

                            <th>isbn</th>
                            <th>title</th>
                            <th>subtitle</th>
                            <th>author</th>
                            <th>pages</th>
                            <th>actions</th>

                        </thead>
                        <tbody>
                            {this.state.books.map((book, ind) => {


                                return (
                                    <tr className={styletr} key={ind}>
                                        <td>{book.isbn}</td>
                                        <td>{book.title}</td>
                                        <td>{book.subtitle}</td>
                                        <td>{book.author}</td>
                                        <td>{book.pages}</td>
                                        <button className="btn btn-primary" onClick={() => this.handleEditbook(ind)} >edit</button>
                                        <button className="btn btn-danger" onClick={() => this.handleRemove(ind)}>delete</button>
                                    </tr>


                                );

                            })}
                        </tbody>
                    </table>

                   {!this.state.updateFlag ?
                        <div>
                            <h3>Add New Books</h3>
                            <BookForm book={this.state.book}  handleAddBook={this.handleAddBook.bind(this)} />
                        </div> :
                        <div>
                            <h3>Update Book detail</h3>
                            <BookForm book={this.state.book} handleAddBook={this.handleAddBook.bind(this)} />
                        </div> 
    }

                       

                </div>
            );.21
}

export default Booklist;