import React from 'react';

class Book extends React.Component {
    constructor(props) {
        super(props);
        this.state = {             
           
            likes:0     
        };

        this.handleClick = () => {
            console.log("button clicked" )
            this.setState({likes:this.state.likes+1})
         }
        
        }
handleLike(){
    console.log("handle like" )
    
    
    this.setState({likes:this.state.likes+1})
}

handleunLike(){
    console.log("handle unlike" )
    this.setState({likes:this.state.likes-1})
}

 
    render() {
        return (
            <div>
                <div>
                
                <p>likes- {this.state.likes}</p>
                <button onClick={()=>this.handleLike()} >Like</button>
                <button onClick={()=>this.handleunLike()}>unLike</button>
                <button onClick={this.handleClick}>click</button>


              </div>

            </div>
        );
    }
}

export default Book;