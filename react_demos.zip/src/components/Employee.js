import React from 'react';

export const Employee = (props) => {
    return (
        <div className="alert alert-secondary" role="alert"><h4>name:{props.name}</h4>
        <button className="btn btn-primary" >UpVote</button>
        </div>
        
    );
}

// export default Employee;