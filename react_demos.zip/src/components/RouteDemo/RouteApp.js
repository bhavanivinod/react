import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link,NavLink ,Redirect,Prompt, Switch} from "react-router-dom";

const user = ({match}) => {
    return (
        <div>
            <h1>welcome user {match.params.username}</h1>
          
        </div>
        
    );
}

const Customer = (props) => {
    return (
        <div>
            <h1>welcome user {props.username}</h1>
          
        </div>
        
    );
}

const PageNot = (props) => {
    return (
        <div>
            <h1>page Not found</h1>
          
        </div>
        
    );
}


class RouteApp extends Component {
    constructor(props) {
        super(props);
        this.state = {

            name:'Bob',
            isloggedin: false
          };
    }

    handleOnClick() {

        this.setState(prevState => ({
          
          isloggedin: !prevState.isloggedin 
        }))
      }

    render() {
        return (
            <Router>
          <>
          <Prompt
            when={!this.state.isloggedin}   message={(location)=>{
                return location.pathname.startsWith('/customer') ? 'Have U logged In?' : true
              }}/>
<Prompt when={!this.state.isloggedin} message="Are you sure you want to leave?" />

          <NavLink to="/aboutus" activeStyle={ {color:'pink'}}>About US</NavLink>
          <NavLink to={`/user/${this.state.name}`} activeStyle={ {color:'pink'}}>User</NavLink>
          <NavLink to={`/customer/${this.state.name}`} activeStyle={ {color:'pink'}}>customer</NavLink>

          <NavLink to="/Home" activeStyle={ {color:'pink'}}>Home</NavLink> <br/>
          <Switch>
          <Route path="/Home" exact strict render={
          () => {
            return ( <h1>Welcome Home</h1>);
          }
        }/>

<Route path="/aboutus" exact strict render={
          () => {
            return ( <h1>About us page</h1>);
          }
        }/>

<Route path="/customer/:username" exact strict render={({match})=>{
   return this.state.isloggedin?(<Customer username={match.params.username}/>):(<Redirect to="/Home"></Redirect>)
}}/>


<Route path="/user/:username" exact strict component={user} />

<Route exact  component={PageNot}/>
        </Switch>
<input type="button" onClick={()=>this.handleOnClick()}  value={this.state.isloggedin ? 'log out': 'log in'}/>
          </> 
          </Router>
        );
    }
}

export default RouteApp;