import React, { Component } from 'react';

class Lifecycledemo extends Component {
    constructor(props) {
        super(props);
        console.log("constructor tiggered")
        this.state = { name:'' };
    }

    handleOnchange(event)
{
    this.setState({name:event.target.value})
}

componentWillMount()
{
    console.log("component will be mounted")
}

componentDidMount()
{
    console.log("component mounted")
}
componentWillUpdate(nextProps,nextState)
{
    console.log("component will be updated with"+nextState.name) 
}

componentDidUpdate(prevProps,prevState)
{
    console.log("component updated with"+prevState.name) 
}

    render() {
        console.log("render method")
        return (
            <>
          <p>{this.state.name}</p>

          <input type="text" name="name" onChange={(event)=>this.handleOnchange(event)
        }/>
            </>
        );
    }
}

export default Lifecycledemo;