import React,{Component} from 'react';
import AddLIst from './AddLIst';

class ListDemo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            books:["xxxx","rrrrr","uyyyy"]
          };
         
    }


    handleRemove(ind)
    {
        const current=this.state;
        let newstate=current.books.filter((book,index)=>{
return index!=ind
        });
        this.setState({books:newstate})

    }
    handleAdd(name)
    {
        console.log("calling parent add");
        let newstate=[...this.state.books,name]
        console.log(newstate);
        this.setState({books:newstate})            

    }

    

    
    render() {
        return (

            <div>
                <AddLIst handleAdd={this.handleAdd.bind(this)}/>
{this.state.books.map((book,ind)=>{
    return(<div><li key={ind}>
        {book}
        <button onClick={()=>this.handleRemove(ind)}>remove</button>
        
        </li>
        
        </div>)


})}

            </div>
        );
    }
}

export default ListDemo;