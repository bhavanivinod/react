import React, { Component } from 'react';
import './styles.css';
import {connect} from 'react-redux'
//import { Chart } from "react-charts";



class BankApp extends Component {


  render()
  {
  return (
    <div className="App">
      <div style={{fontSize:'25px',fontFamily:'monospace',fontWeight:'bold'}}>amount:<span >{this.props.amount}</span></div>
      <input type="text" onChange={(e)=>this.props.onTextChange(e)}/> 
      <button onClick={this.props.onWithdarwMoney}>withdraw</button>
      <button onClick={this.props.onDepositMoney}>deposit</button>
      <hr/>
{/* <div>
  <h1>{this.props.inputValue}</h1>
</div> */}

      <div>History</div>
        <div>
          <ul>
            {this.props.history.map(el => (
              <li 
                className="historyItem" 
                key={el.id}
                onClick={() => this.props.onDelEntry(el.id)}>
                {el.amount}{el.message}
              </li>
            ))}
          </ul>
        </div>
    </div>
  );
}
}

 const mapStateToProps=(state)=>{
return{
  amount:state.amount,
  history:state.history,
  inputValue:state.inputValue
}
};



const mapDispachToProps=(dispatch)=>{
  return {
    
    onWithdarwMoney:()=>dispatch({type:'WITHDRAW'}),
    onDepositMoney:()=>dispatch({type:'DEPOSIT'}),
    onDelEntry: (id) => dispatch({ type: "DEL_ENTRY", id: id}),
    onTextChange:(evt)=> dispatch({ type: "INPUT_ENTRY", value:evt.target.value})
  }
};



export default connect(mapStateToProps,mapDispachToProps)(BankApp);
