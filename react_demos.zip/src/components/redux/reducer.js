const initialState={
    votes:0
}

const reducer=(state=initialState,action)=>{
const newState={...state}
switch(action.type)
{
    case "VOTE_UP":
    newState.votes=newState.votes+action.data;break;
    case "VOTE_DOWN":
    newState.votes=newState.votes-action.data;
    break;
    
}
return newState;

}


export default reducer;