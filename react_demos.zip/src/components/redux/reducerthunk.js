const initialState = {
    votes: 20
  };
  
  const reducerthunk = (state = initialState, action) => {
    const newState = { ...state };
  
    switch (action.type) {
      case "VOTE_UP":
        newState.votes += action.value;
        newState.loading = false;
        break;
  
      case "VOTE_DOWN":
        newState.votes -= action.value;
        break;
      case "LOADING":
        newState.loading = true;
    }
    return newState;
  };
  
  export default reducerthunk;