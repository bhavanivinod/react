import React, { Component } from 'react';
import {connect} from 'react-redux'
import * as actionCreater from './actions'
class DemoThunk extends Component {
    constructor(props) {
        super(props);
        this.state = { 
//votes:10

         };
    }
    render() {
        return (
            <div>
                <h1>
                    {this.props.votes}
                    {this.props.loading && <h4>loading....</h4>}
                </h1>
                <button onClick={this.props.onVoteUp}>upVote</button>
                <button onClick={this.props.onVoteDown}>downVote</button>
            </div>
        );
    }
}

const mapStateToProps=(state)=>{
return{
    votes:state.votes,
    loading:state.loading
}
}

const mapDispatchToProps=(dispatch)=>{
return{
    onVoteUp:()=>dispatch(actionCreater.voteUp(1)),
    onVoteDown:()=>dispatch(actionCreater.voteDown(1))
}
}

export default connect(mapStateToProps,mapDispatchToProps) (DemoThunk);