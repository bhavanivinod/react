import React, { Component } from 'react';
import {connect} from 'react-redux'
class Demo extends Component {
    constructor(props) {
        super(props);
        this.state = { 
//votes:10

         };
    }
    render() {
        return (
            <div>
                <h1>
                    {this.props.votes}
                </h1>
                <button onClick={this.props.onVoteUp}>upVote</button>
                <button onClick={this.props.onVoteDown}>downVote</button>
            </div>
        );
    }
}

const mapStateToProps=(state)=>{
return{
    votes:state.votes
}
}

const mapDispatchToProps=(dispatch)=>{
return{
    onVoteUp:()=>dispatch({type:'VOTE_UP',data:5}),
    onVoteDown:()=>dispatch({type:'VOTE_DOWN',data:2})
}
}

export default connect(mapStateToProps,mapDispatchToProps) (Demo);