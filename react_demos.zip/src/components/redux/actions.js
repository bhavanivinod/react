export const loading = () => {
    return {
      type: "LOADING"
    };
  };
  
  export const voteUpAsnc = val => {
    return { type: "VOTE_UP", value: val };
  };
  
  export const voteUp = val => {
    return dispach => {
      dispach(loading());
      setTimeout(() => {
        dispach(voteUpAsnc(val));
      }, 5000);
    };
  };
  
  export const voteDown = val => {
    return { type: "VOTE_DOWN", value: val };
  };