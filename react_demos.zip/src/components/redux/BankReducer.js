const initialState ={
    amount:5000,
    history: [],
    inputValue:0

    };
    
    const BankReducer=(state=initialState,action)=>{
    const newState={...state};
    if(action.type==='WITHDRAW')
    {
        newState.amount-=newState.inputValue;
        newState.history= state.history.concat({ id: Math.random(), amount: state.amount -state.inputValue,message:'withdrawn' });
    }
    if(action.type==='DEPOSIT')
    {
        newState.amount+=newState.inputValue;
        newState.history= state.history.concat({ id: Math.random(), amount: state.amount + state.inputValue ,message:'deposited' });
    }
    if(action.type==='DEL_ENTRY')
    {
       newState.history= newState.history.filter((el)=> el.id !== action.id )
    }
    if(action.type==='INPUT_ENTRY')
    {
       newState.inputValue=parseInt(action.value);
    }

    return newState;
    };
    
    export default BankReducer;