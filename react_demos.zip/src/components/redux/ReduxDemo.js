import React, { Component } from 'react';


class ReduxDemo extends Component {
    constructor(props) {
        super(props);
        this.state = { votes:0 };
    }
handleclickDownvote(){

    this.setState({...this.state,votes:--this.state.votes})

}

handleclickUpvote(){
    this.setState({...this.state,votes:++this.state.votes})
}


    render() {
        return (
            <div>
<h1>{this.state.votes}</h1>
<button onClick={()=>this.handleclickUpvote()}>up vote</button>
<button onClick={()=>this.handleclickDownvote()}>down vote</button>
            </div>
        );
    }
}

export default ReduxDemo;