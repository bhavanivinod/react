import React, { Component } from 'react';

class AddLIst extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            name:null
         };
    }


    handleClick()
    {
        console.log("click fn working")
   this.props.handleAdd(this.state.name);
    }
    handleAdd(e)
    { 
        this.setState({name:e.target.value})
    
    }
    
        

    render() {
        return (
            <div>
                <input type="text" name="bookname" onChange={(event)=>this.handleAdd(event)}/>
                <button onClick={()=>this.handleClick()} >Add</button>
            </div>
        );
    }
}

export default AddLIst;

